var banana,obstacle,ObstaclesGroup,background,score
function preload() {
backImage = loadImage("jungle.jpg")
monkey_running= loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_8.png","Monkey_09.png","Monkey_10.png")
  banana = loadImage("banana.png")
  obstacle = loadImage("stone.png")
}
function setup() {
  createCanvas(400, 400);
  background = createSprite = (200,200)
  background.addImage(jungle.jpg)
  background.velocityX = -4
  ground = createSprite = (200,200,400,1)
  ground.visibilty = false
  Monkey.addAnimation = 
}

function draw() {
  background(220);
}